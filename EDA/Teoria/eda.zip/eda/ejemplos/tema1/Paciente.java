package ejemplos.tema1;

public class Paciente {
    private int numero;
    
    public Paciente(int n) { this.numero = n; }
    public String toString() { return "Paciente numero " + this.numero; }
}