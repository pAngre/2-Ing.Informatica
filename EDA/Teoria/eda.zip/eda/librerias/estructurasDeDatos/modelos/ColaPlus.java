package librerias.estructurasDeDatos.modelos;

public interface ColaPlus<E> extends Cola<E> {
    /** obtiene la talla de una Cola 
     */
    int talla();
}